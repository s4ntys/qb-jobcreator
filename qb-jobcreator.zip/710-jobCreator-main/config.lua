Config = {}

Config.updatedOxmySql = true --- true = no exports, false = exports 

Config.CommandName = 'createjob'